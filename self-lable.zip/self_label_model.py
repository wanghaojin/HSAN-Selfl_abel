import argparse
import warnings
import os
import time
import numpy as np

import torch
import torch.optim
import torch.nn as nn
import torch.utils.data
try:
    from tensorboardX import SummaryWriter
except:
    pass

import files
import util
import sinkhornknopp as sk
from data import return_model_loader
warnings.simplefilter("ignore", UserWarning)

class Optimizer:
    def __init__(self,m,hc,ncl,t_loader,n_epochs,lr,weight_decay=1e-5,ckpt_dir='/'):
        self.num_epochs = n_epochs






